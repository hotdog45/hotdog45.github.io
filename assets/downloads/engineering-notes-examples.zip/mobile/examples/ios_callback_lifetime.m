#import <Foundation/Foundation.h>

@interface FakeTask : NSObject
@property(nonatomic, copy) void (^completion)(NSString *);
@property(nonatomic) BOOL cancelled;
@property(nonatomic) BOOL completesOnCancel;
- (void)cancel;
- (void)deliver:(NSString *)value;
@end

@implementation FakeTask
- (void)cancel {
    self.cancelled = YES;
    if (self.completesOnCancel) [self deliver:@"cancel-synchronously"];
}
- (void)deliver:(NSString *)value {
    // Deliberately allow a late completion after cancel in this test double.
    void (^completion)(NSString *) = self.completion;
    self.completion = nil;
    if (completion) completion(value);
}
@end

@interface RequestOwner : NSObject
@property(nonatomic, strong) FakeTask *task;
@property(nonatomic, copy) NSString *value;
@property(nonatomic) NSUInteger generation;
@property(nonatomic) NSUInteger updates;
- (FakeTask *)start;
- (void)cancelCurrent;
@end

@implementation RequestOwner
- (FakeTask *)start {
    NSUInteger ticket = ++self.generation;
    [self.task cancel];
    FakeTask *task = [FakeTask new];
    self.task = task;
    __weak RequestOwner *weakSelf = self;
    task.completion = ^(NSString *value) {
        RequestOwner *owner = weakSelf;
        if (!owner || ticket != owner.generation) return;
        owner.task = nil;
        owner.value = value;
        owner.updates += 1;
    };
    return task;
}
- (void)cancelCurrent {
    self.generation += 1;
    [self.task cancel];
    self.task = nil;
}
@end

static void check(BOOL condition, const char *message) {
    if (!condition) {
        fprintf(stderr, "FAIL: %s\n", message);
        exit(1);
    }
}

int main(void) {
    @autoreleasepool {
        RequestOwner *owner = [RequestOwner new];
        FakeTask *old = [owner start];
        FakeTask *current = [owner start];
        [old deliver:@"stale"];
        check(owner.updates == 0, "old result ignored");
        [current deliver:@"new"];
        check([owner.value isEqualToString:@"new"], "current result accepted");
        check(owner.updates == 1, "one accepted update");

        FakeTask *cancelled = [owner start];
        [owner cancelCurrent];
        [cancelled deliver:@"late"];
        check(owner.updates == 1, "cancelled result ignored");

        FakeTask *syncOld = [owner start];
        syncOld.completesOnCancel = YES;
        FakeTask *replacement = [owner start];
        check(syncOld.completion == nil, "cancel synchronously delivered completion");
        check(owner.updates == 1, "synchronous cancel cannot update old result");
        check(owner.task == replacement, "replacement task remains current");
        [replacement deliver:@"replacement"];
        check(owner.updates == 2, "replacement result still accepted");

        __weak RequestOwner *weakOwner = owner;
        FakeTask *retainedByTransport = [owner start];
        owner = nil;
        check(weakOwner == nil, "callback does not retain owner");
        [retainedByTransport deliver:@"after release"];
        check(retainedByTransport.completion == nil, "completion released");
        puts("PASS: stale, current, cancelled, synchronous-cancel, released-owner, completion-release");
    }
    return 0;
}
