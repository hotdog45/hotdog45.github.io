import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class AndroidStateRecovery {
    static final class SearchState {
        final String query;
        final String anchorId;
        final int offset;

        SearchState(String query, String anchorId, int offset) {
            this.query = query;
            this.anchorId = anchorId;
            this.offset = offset;
        }

        Map<String, String> save() {
            Map<String, String> snapshot = new HashMap<>();
            snapshot.put("schema", "1");
            snapshot.put("query", query);
            snapshot.put("anchor", anchorId);
            snapshot.put("offset", Integer.toString(offset));
            return snapshot;
        }

        static SearchState restore(Map<String, String> snapshot, String newRouteQuery) {
            if (newRouteQuery != null) return fresh(newRouteQuery);
            if (snapshot == null || !"1".equals(snapshot.get("schema"))) return fresh("");
            String query = snapshot.get("query");
            String anchor = snapshot.get("anchor");
            if (query == null || query.length() > 200 || anchor == null) return fresh("");
            try {
                int offset = Integer.parseInt(snapshot.get("offset"));
                if (offset < 0 || offset > 10000) return fresh("");
                return new SearchState(query, anchor, offset);
            } catch (NumberFormatException invalid) {
                return fresh("");
            }
        }

        static SearchState fresh(String query) { return new SearchState(query, "", 0); }

        int anchorIndexAfterLoad(List<String> itemIds) {
            int index = itemIds.indexOf(anchorId);
            return index < 0 ? 0 : index;
        }
    }

    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    public static void main(String[] args) {
        SearchState original = new SearchState("camera", "item-9", 120);
        Map<String, String> snapshot = original.save();
        SearchState restored = SearchState.restore(snapshot, null);
        check(restored.query.equals("camera"), "query restored before reload");
        check(restored.offset == 120, "small viewport offset retained");
        check(restored.anchorIndexAfterLoad(Arrays.asList("item-8", "item-9")) == 1,
                "anchor located after data arrives");
        check(restored.anchorIndexAfterLoad(Arrays.asList("item-8")) == 0,
                "removed anchor falls back");
        SearchState redirected = SearchState.restore(snapshot, "laptop");
        check(redirected.query.equals("laptop") && redirected.anchorId.isEmpty(),
                "explicit new route overrides prior snapshot");
        check(SearchState.restore(snapshot, "").query.isEmpty(), "explicit clear is not missing");
        Map<String, String> unknown = new HashMap<>(snapshot);
        unknown.put("schema", "2");
        check(SearchState.restore(unknown, null).query.isEmpty(), "unknown snapshot rejected");
        Map<String, String> corrupt = new HashMap<>(snapshot);
        corrupt.put("offset", "not-a-number");
        check(SearchState.restore(corrupt, null).offset == 0, "corrupt offset handled");
        check(SearchState.restore(null, null).query.isEmpty(), "fresh start independent of snapshot");
        check(!snapshot.containsKey("items") && !snapshot.containsKey("loading"),
                "derived state excluded");
        System.out.println("PASS: 10 state-recovery contract assertions; no Android runtime");
    }
}
