import 'dart:convert';

// Current Dart validation model, not a Flutter 1.0 host implementation.
class RouteGate {
  int sessionRevision = 7;
  final Map<String, String> accepted = <String, String>{};
  int opened = 0;

  Map<String, dynamic> handle(Map<String, dynamic> message) {
    final dynamic version = message['version'];
    if (version is! int || version != 1) return result('unsupported_version');
    final dynamic id = message['requestId'];
    final dynamic revision = message['sessionRevision'];
    final dynamic payload = message['payload'];
    if (id is! String || id.isEmpty || revision is! int || payload is! Map) {
      return result('invalid_request');
    }
    if (message['method'] != 'openOrder') return result('unknown_method');
    if (revision != sessionRevision) return result('stale_session');
    final dynamic orderId = payload['orderId'];
    if (orderId is! String || !RegExp(r'^demo-[0-9]+$').hasMatch(orderId)) {
      return result('invalid_order_id');
    }
    final String key = '$revision:$id';
    if (accepted.containsKey(key)) {
      return result(accepted[key] == orderId ? 'duplicate' : 'id_conflict');
    }
    accepted[key] = orderId;
    opened += 1;
    return result('accepted');
  }

  void logout() {
    sessionRevision += 1;
    accepted.clear();
  }

  Map<String, dynamic> result(String status) => <String, dynamic>{'status': status};
}

Map<String, dynamic> request(String id, String order, {int revision = 7}) =>
    <String, dynamic>{
      'version': 1,
      'requestId': id,
      'method': 'openOrder',
      'sessionRevision': revision,
      'payload': <String, dynamic>{'orderId': order},
    };

void expectStatus(RouteGate gate, Map<String, dynamic> message, String expected) {
  final String actual = gate.handle(message)['status'] as String;
  if (actual != expected) throw StateError('$actual != $expected');
}

void main() {
  final RouteGate gate = RouteGate();
  expectStatus(gate, request('r1', 'demo-42'), 'accepted');
  expectStatus(gate, request('r1', 'demo-42'), 'duplicate');
  expectStatus(gate, request('r1', 'demo-99'), 'id_conflict');
  expectStatus(gate, request('r2', 'not-an-order'), 'invalid_order_id');
  final Map<String, dynamic> wrongMethod = request('r2', 'demo-42');
  wrongMethod['method'] = 'deleteAccount';
  expectStatus(gate, wrongMethod, 'unknown_method');
  final Map<String, dynamic> wrongVersion = request('r2', 'demo-42');
  wrongVersion['version'] = 2;
  expectStatus(gate, wrongVersion, 'unsupported_version');
  final Map<String, dynamic> decimalVersion = request('r2', 'demo-42');
  decimalVersion['version'] = 1.0;
  expectStatus(gate, decimalVersion, 'unsupported_version');
  final Map<String, dynamic> malformed = request('r2', 'demo-42');
  malformed['payload'] = 'wrong shape';
  expectStatus(gate, malformed, 'invalid_request');
  gate.logout();
  expectStatus(gate, request('r3', 'demo-42'), 'stale_session');
  expectStatus(gate, request('r3', 'demo-42', revision: 8), 'accepted');
  if (gate.opened != 2) throw StateError('unexpected side effect count');
  print(jsonEncode(<String, dynamic>{
    'passed': 10,
    'opened': gate.opened,
    'scope': 'pure Dart protocol model; no Flutter engine or device',
  }));
}
