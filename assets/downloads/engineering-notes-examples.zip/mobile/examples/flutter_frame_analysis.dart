import 'dart:convert';
import 'dart:math';

class Sample {
  final double buildMs;
  final double rasterMs;
  Sample(this.buildMs, this.rasterMs);
}

Map<String, dynamic> analyze(double hz, List<Sample> samples) {
  if (!hz.isFinite || hz <= 0 || samples.isEmpty) {
    throw ArgumentError('positive refresh rate and nonempty samples required');
  }
  final double budgetMs = 1000 / hz;
  int uiSlow = 0, rasterSlow = 0, eitherSlow = 0, bothSlow = 0;
  final List<double> stageMax = <double>[];
  for (final Sample sample in samples) {
    if (!sample.buildMs.isFinite || !sample.rasterMs.isFinite ||
        sample.buildMs < 0 || sample.rasterMs < 0) {
      throw ArgumentError('finite nonnegative durations required');
    }
    final bool ui = sample.buildMs > budgetMs;
    final bool raster = sample.rasterMs > budgetMs;
    if (ui) uiSlow += 1;
    if (raster) rasterSlow += 1;
    if (ui || raster) eitherSlow += 1;
    if (ui && raster) bothSlow += 1;
    stageMax.add(max(sample.buildMs, sample.rasterMs));
  }
  stageMax.sort();
  return <String, dynamic>{
    'samples': samples.length,
    'refreshHz': hz,
    'stageBudgetMs': budgetMs,
    'uiOverBudget': uiSlow,
    'rasterOverBudget': rasterSlow,
    'eitherOverBudget': eitherSlow,
    'bothOverBudget': bothSlow,
    'stageMaxP95Ms': stageMax[(0.95 * stageMax.length).ceil() - 1],
    'measurementKind': 'synthetic stage diagnostics, not displayed-frame latency',
  };
}

void check(bool condition, String name) {
  if (!condition) throw StateError(name);
}

void main() {
  final Map<String, dynamic> report = analyze(60, <Sample>[
    Sample(4, 5), Sample(20, 7), Sample(7, 22), Sample(18, 21),
  ]);
  check(report['uiOverBudget'] == 2, 'UI diagnosis');
  check(report['rasterOverBudget'] == 2, 'raster diagnosis');
  check(report['eitherOverBudget'] == 3, 'union, not sum');
  check(report['bothOverBudget'] == 1, 'overlap retained');
  check(report['stageMaxP95Ms'] == 22, 'nearest-rank diagnostic percentile');
  check(analyze(60, <Sample>[Sample(10, 10)])['eitherOverBudget'] == 0,
      'do not sum pipelined stages');
  check(analyze(120, <Sample>[Sample(10, 10)])['bothOverBudget'] == 1,
      'refresh rate changes budget');
  int rejected = 0;
  for (final void Function() invalid in <void Function()>[
    () => analyze(0, <Sample>[Sample(1, 1)]),
    () => analyze(60, <Sample>[]),
    () => analyze(60, <Sample>[Sample(double.nan, 1)]),
  ]) {
    try { invalid(); } on ArgumentError { rejected += 1; }
  }
  check(rejected == 3, 'invalid inputs rejected');
  print(jsonEncode(<String, dynamic>{'assertions': 10, 'fixtureReport': report}));
}
