Engineering notes examples — Xiaofeng Qiao

Portable sources accompanying the 24 reviewed notes. Grouped under mobile, web-data and systems.
Use disposable local environments. Tests of pure models do not prove device, framework, database or external-service integration.
Java 21, SQL and Redis Lua examples need the matching runtime/server for integration checks. No production credentials, customer source, binaries or review records are included.
The two additional Vue/TypeScript and Web3 articles explain their snippet validation separately in the article.
