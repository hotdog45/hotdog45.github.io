function makeSaveAction(save, onOptimistic = () => {}) {
  return async function action(previous, formData) {
    if (!formData || typeof formData.get !== 'function') {
      return { kind: 'invalid', message: '表单结构错误' };
    }
    const rawName = formData.get('name');
    const rawKey = formData.get('requestKey');
    if (typeof rawName !== 'string' || typeof rawKey !== 'string') {
      return { kind: 'invalid', message: '请检查输入类型' };
    }
    const name = rawName.trim(), requestKey = rawKey.trim();
    if (!name || name.length > 80
        || !/^[a-zA-Z0-9_-]{8,128}$/.test(requestKey)) {
      return { kind: 'invalid', message: '请检查姓名和操作标识' };
    }
    onOptimistic({ name, requestKey });
    try {
      const receipt = await save({ name, requestKey });
      if (!receipt || typeof receipt.id !== 'string' || !receipt.id) {
        return { kind: 'uncertain', message: '结果未确认，请用同一操作重试' };
      }
      return { kind: 'saved', receipt: { id: receipt.id, name, requestKey } };
    } catch (error) {
      if (error && error.code === 'version_conflict') {
        return { kind: 'conflict', message: '资料已有更新，请先核对' };
      }
      if (error && error.code === 'request_conflict') {
        return { kind: 'request_conflict', message: '操作标识已用于其他内容，请核对' };
      }
      return { kind: 'uncertain', message: '结果未确认，请用同一操作重试' };
    }
  };
}

function IntegrationExample() {
const [saved, setSaved] = useState([]);
const [rows, addOptimistic] = useOptimistic(saved, (current, entry) =>
  current.some(row => row.requestKey === entry.requestKey)
    ? current : current.concat({ ...entry, pending: true })
);
const [result, submit, pending] = useActionState(async (previous, data) => {
  const next = await makeSaveAction(save, addOptimistic)(previous, data);
  if (next.kind === 'saved') {
    startTransition(() => setSaved(current =>
      current.some(row => row.id === next.receipt.id)
        ? current : current.concat(next.receipt)
    ));
  }
  return next;
}, { kind: 'idle' });

}
