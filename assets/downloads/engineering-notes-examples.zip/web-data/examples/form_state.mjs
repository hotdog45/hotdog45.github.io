import assert from 'node:assert/strict';

export const initial = () => ({ values: { name: '', email: '' }, errors: {},
  status: 'editing', requestId: null, snapshot: null, message: '' });

export function transition(s, e) {
  if (e.type === 'change') {
    if (s.status === 'submitting' || !['name', 'email'].includes(e.field)) return s;
    const errors = { ...s.errors }; delete errors[e.field];
    return { ...s, values: { ...s.values, [e.field]: e.value }, errors, status: 'editing', message: '' };
  }
  if (e.type === 'submit') {
    if (s.status === 'submitting') return s;
    const snapshot = { name: s.values.name.trim(), email: s.values.email.trim() };
    const errors = {};
    if (!snapshot.name) errors.name = '请输入姓名';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(snapshot.email)) errors.email = '请检查邮箱格式';
    if (Object.keys(errors).length) return { ...s, errors, status: 'editing' };
    return { ...s, errors: {}, status: 'submitting', requestId: e.requestId, snapshot, message: '' };
  }
  if (!['success', 'failure'].includes(e.type) || s.status !== 'submitting' || e.requestId !== s.requestId) return s;
  if (e.type === 'success') return { ...s, status: 'success', message: '已保存' };
  return { ...s, status: 'editing', message: '保存失败，请重试' };
}

let s = initial();
const invalid = transition(s, { type: 'submit', requestId: 1 });
assert.equal(invalid.status, 'editing'); assert.equal(Object.keys(invalid.errors).length, 2);
s = transition(s, { type: 'change', field: 'name', value: ' Demo ' });
s = transition(s, { type: 'change', field: 'email', value: 'demo@example.test' });
const submitted = transition(s, { type: 'submit', requestId: 2 });
assert.equal(submitted.status, 'submitting'); assert.equal(submitted.snapshot.name, 'Demo');
assert.equal(s.values.name, ' Demo '); // no mutation
assert.equal(transition(submitted, { type: 'submit', requestId: 3 }), submitted);
assert.equal(transition(submitted, { type: 'change', field: 'name', value: 'Other' }), submitted);
assert.equal(transition(submitted, { type: 'success', requestId: 1 }), submitted);
const failure = transition(submitted, { type: 'failure', requestId: 2 });
assert.equal(failure.values.email, 'demo@example.test'); assert.equal(failure.status, 'editing');
assert.equal(transition(submitted, { type: 'success', requestId: 2 }).status, 'success');
assert.equal(transition(s, { type: 'change', field: '__proto__', value: 'x' }), s);
console.log('8 form-state behavior checks passed; no React renderer or browser tested');
