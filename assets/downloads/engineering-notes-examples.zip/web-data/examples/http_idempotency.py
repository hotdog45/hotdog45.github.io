"""Application-layer idempotency model. No HTTP listener or external service."""
import hashlib
import json
import sqlite3
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest


class KeyConflict(Exception):
    pass


def initialize(path):
    with sqlite3.connect(path) as db:
        db.executescript("""
            CREATE TABLE orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tenant TEXT NOT NULL,
                sku TEXT NOT NULL,
                quantity INTEGER NOT NULL CHECK (quantity > 0)
            );
            CREATE TABLE receipts (
                tenant TEXT NOT NULL,
                request_key TEXT NOT NULL,
                fingerprint TEXT NOT NULL,
                status INTEGER NOT NULL,
                body TEXT NOT NULL,
                PRIMARY KEY (tenant, request_key)
            );
        """)


def create_order(path, tenant, key, payload, fail_before_receipt=False):
    """Fixed POST /orders contract; tenant is an already authenticated identity."""
    if not tenant or not key or len(key) > 128:
        raise ValueError("invalid scope or key")
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    if set(payload) != {"sku", "quantity"}:
        raise ValueError("unexpected or missing field")
    if not isinstance(payload["sku"], str) or not payload["sku"]:
        raise ValueError("invalid sku")
    if type(payload["quantity"]) is not int or payload["quantity"] <= 0:
        raise ValueError("quantity must be a positive integer")
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    db = sqlite3.connect(path, isolation_level=None, timeout=10)
    try:
        db.execute("BEGIN IMMEDIATE")
        old = db.execute(
            "SELECT fingerprint, status, body FROM receipts "
            "WHERE tenant = ? AND request_key = ?", (tenant, key)
        ).fetchone()
        if old:
            if old[0] != fingerprint:
                raise KeyConflict("key reused with a different payload")
            db.commit()
            return old[1], old[2], True
        order_id = db.execute(
            "INSERT INTO orders(tenant, sku, quantity) VALUES (?, ?, ?)",
            (tenant, payload["sku"], payload["quantity"])
        ).lastrowid
        if fail_before_receipt:
            raise RuntimeError("injected failure before receipt")
        body = json.dumps({"orderId": order_id}, separators=(",", ":"))
        db.execute("INSERT INTO receipts VALUES (?, ?, ?, ?, ?)",
                   (tenant, key, fingerprint, 201, body))
        db.commit()
        return 201, body, False
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


class IdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.path = str(Path(self.temp.name) / "orders.sqlite")
        initialize(self.path)
        self.payload = {"sku": "demo-widget", "quantity": 1}

    def tearDown(self):
        self.temp.cleanup()

    def count(self, table):
        assert table in {"orders", "receipts"}
        with sqlite3.connect(self.path) as db:
            return db.execute("SELECT count(*) FROM " + table).fetchone()[0]

    def test_response_loss_and_replay_after_new_connection(self):
        first = create_order(self.path, "tenant-a", "request-1", self.payload)
        replay = create_order(self.path, "tenant-a", "request-1", self.payload)
        self.assertEqual(first[:2], replay[:2])
        self.assertFalse(first[2])
        self.assertTrue(replay[2])
        self.assertEqual(self.count("orders"), 1)

    def test_key_cannot_change_payload(self):
        create_order(self.path, "tenant-a", "request-1", self.payload)
        with self.assertRaises(KeyConflict):
            create_order(self.path, "tenant-a", "request-1",
                         {"sku": "demo-widget", "quantity": 2})
        self.assertEqual(self.count("orders"), 1)

    def test_same_key_is_isolated_by_tenant(self):
        create_order(self.path, "tenant-a", "request-1", self.payload)
        create_order(self.path, "tenant-b", "request-1", self.payload)
        self.assertEqual(self.count("orders"), 2)

    def test_business_write_and_receipt_rollback_together(self):
        with self.assertRaises(RuntimeError):
            create_order(self.path, "tenant-a", "request-1", self.payload, True)
        self.assertEqual(self.count("orders"), 0)
        self.assertEqual(self.count("receipts"), 0)

    def test_concurrent_duplicates_create_one_order(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(
                lambda _: create_order(self.path, "tenant-a", "request-1", self.payload),
                range(8)))
        self.assertEqual(len({r[:2] for r in results}), 1)
        self.assertEqual(sum(not r[2] for r in results), 1)
        self.assertEqual(self.count("orders"), 1)
        self.assertEqual(self.count("receipts"), 1)

    def test_rejects_boolean_quantity(self):
        with self.assertRaises(ValueError):
            create_order(self.path, "tenant-a", "request-1",
                         {"sku": "demo-widget", "quantity": True})
        self.assertEqual(self.count("orders"), 0)

    def test_rejects_null_payload_as_value_error(self):
        with self.assertRaises(ValueError):
            create_order(self.path, "tenant-a", "request-1", None)
        self.assertEqual(self.count("orders"), 0)

    def test_rejects_array_payload_as_value_error(self):
        with self.assertRaises(ValueError):
            create_order(self.path, "tenant-a", "request-1", ["sku", "quantity"])
        self.assertEqual(self.count("orders"), 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
