import assert from 'node:assert/strict';

export function beginLoad(id, load, publish) {
  let active = true;
  publish({ id, status: 'loading', data: null, error: null });
  const done = Promise.resolve().then(() => load(id)).then(
    data => { if (active) publish({ id, status: 'success', data, error: null }); },
    () => { if (active) publish({ id, status: 'error', data: null, error: 'load_failed' }); }
  );
  return { done, cleanup() { active = false; } };
}
export function visible(state, id) {
  return state.id === id ? state : { id, status: 'loading', data: null, error: null };
}
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
};

const a = deferred(), b = deferred();
const events = [];
const first = beginLoad('a', () => a.promise, x => events.push(x));
first.cleanup();
const second = beginLoad('b', () => b.promise, x => events.push(x));
b.resolve('B'); await second.done;
a.resolve('A'); await first.done;
assert.equal(events[events.length - 1].data, 'B');
assert.equal(events.filter(x => x.status === 'success').length, 1);
assert.equal(visible(events[events.length - 1], 'c').status, 'loading');
assert.equal(visible(events[events.length - 1], 'b').data, 'B');
const rejected = deferred(), cleanupEvents = [];
const removed = beginLoad('x', () => rejected.promise, x => cleanupEvents.push(x));
removed.cleanup(); rejected.reject(new Error('expected')); await removed.done;
assert.equal(cleanupEvents.length, 1);
const errors = [];
await beginLoad('x', () => { throw new Error('sync'); }, x => errors.push(x)).done;
assert.equal(errors[1].status, 'error');
assert.equal(errors[1].error, 'load_failed');
console.log('7 effect-ownership checks passed; React scheduling, renderer and network not tested');
