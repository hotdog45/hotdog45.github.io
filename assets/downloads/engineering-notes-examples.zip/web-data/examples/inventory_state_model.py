"""Pure state-machine checks. This is NOT a PostgreSQL/MVCC emulator."""
from copy import deepcopy
from itertools import permutations
import unittest


def reserve(state, request, quantity, fail_after_decrement=False):
    if quantity <= 0:
        raise ValueError("invalid quantity")
    if request in state["reservations"]:
        if state["reservations"][request] != quantity:
            raise ValueError("request reused")
        return "replayed"
    transaction = deepcopy(state)
    if transaction["available"] < quantity:
        raise ValueError("insufficient stock")
    transaction["available"] -= quantity
    transaction["version"] += 1
    transaction["reservations"][request] = quantity
    if fail_after_decrement:
        raise RuntimeError("injected abort")
    state.clear()
    state.update(transaction)
    return "created"


def compare_and_set(state, expected_version, new_available):
    if state["version"] != expected_version or new_available < 0:
        return False
    state["available"] = new_available
    state["version"] += 1
    return True


class InventoryModelTests(unittest.TestCase):
    def fresh(self):
        return {"available": 1, "version": 0, "reservations": {}}

    def test_each_serial_order_accepts_only_one_reservation(self):
        for order in permutations(["a", "b"]):
            state, accepted = self.fresh(), 0
            for request in order:
                try:
                    reserve(state, request, 1)
                    accepted += 1
                except ValueError:
                    pass
            self.assertEqual((accepted, state["available"], state["version"]), (1, 0, 1))

    def test_replay_has_no_second_decrement(self):
        state = self.fresh()
        self.assertEqual(reserve(state, "a", 1), "created")
        self.assertEqual(reserve(state, "a", 1), "replayed")
        self.assertEqual(state["available"], 0)
        self.assertEqual(len(state["reservations"]), 1)

    def test_input_change_is_not_replay(self):
        state = self.fresh()
        reserve(state, "a", 1)
        with self.assertRaises(ValueError):
            reserve(state, "a", 2)

    def test_aborted_transaction_publishes_no_changes(self):
        state = self.fresh()
        before = deepcopy(state)
        with self.assertRaises(RuntimeError):
            reserve(state, "a", 1, True)
        self.assertEqual(state, before)

    def test_stale_version_cannot_overwrite(self):
        state = self.fresh()
        self.assertTrue(compare_and_set(state, 0, 5))
        self.assertFalse(compare_and_set(state, 0, 9))
        self.assertEqual((state["available"], state["version"]), (5, 1))

    def test_read_then_absolute_write_can_hide_overselling(self):
        state = self.fresh()
        old_a = old_b = state["available"]
        state["available"] = old_a - 1
        state["reservations"]["a"] = 1
        state["available"] = old_b - 1
        state["reservations"]["b"] = 1
        self.assertEqual(state["available"], 0)
        self.assertGreater(sum(state["reservations"].values()), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
