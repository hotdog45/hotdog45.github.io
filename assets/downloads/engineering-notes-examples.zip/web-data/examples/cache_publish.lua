-- Redis 6-compatible teaching script. Not executed against Redis here.
-- KEYS[1]: refresh lock; KEYS[2]: cached value. Both keys must share a cluster slot.
-- ARGV[1]: unique owner token; ARGV[2]: serialized value; ARGV[3]: positive TTL in ms.
local ttl = tonumber(ARGV[3])
if not ttl or ttl <= 0 or ttl ~= math.floor(ttl) then
  return redis.error_reply('invalid cache TTL')
end
if redis.call('GET', KEYS[1]) ~= ARGV[1] then
  return 0
end
redis.call('SET', KEYS[2], ARGV[2], 'PX', ttl)
redis.call('DEL', KEYS[1])
return 1
