-- MySQL 5.7-compatible example; use a disposable test database only.
-- Not executed in this workspace.
CREATE TABLE blog_demo_orders (
  id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
  tenant_id BIGINT UNSIGNED NOT NULL,
  status VARCHAR(16) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  total_minor BIGINT NOT NULL,
  KEY ix_feed (tenant_id, status, created_at, id)
) ENGINE=InnoDB;

EXPLAIN SELECT id, created_at, total_minor
FROM blog_demo_orders
WHERE tenant_id = 7 AND status = 'open'
ORDER BY created_at DESC, id DESC
LIMIT 50;

EXPLAIN SELECT id, created_at, total_minor
FROM blog_demo_orders
WHERE tenant_id = 7 AND status = 'open'
  AND (created_at < '2016-05-01 10:00:00.000001'
       OR (created_at = '2016-05-01 10:00:00.000001' AND id < 9007199254740995))
ORDER BY created_at DESC, id DESC
LIMIT 50;
