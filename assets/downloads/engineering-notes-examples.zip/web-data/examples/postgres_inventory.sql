-- Run only in a disposable test database, never a production database.
-- PostgreSQL 12-compatible teaching fixture. Not executed in this workspace.
CREATE SCHEMA blog_order_demo;

CREATE TABLE blog_order_demo.inventory (
  sku text PRIMARY KEY,
  available integer NOT NULL CHECK (available >= 0),
  version integer NOT NULL DEFAULT 0
);

CREATE TABLE blog_order_demo.reservations (
  request_id text PRIMARY KEY,
  sku text NOT NULL REFERENCES blog_order_demo.inventory(sku),
  quantity integer NOT NULL CHECK (quantity > 0)
);

INSERT INTO blog_order_demo.inventory(sku, available) VALUES ('demo-widget', 1);

CREATE FUNCTION blog_order_demo.reserve(
  p_request text, p_sku text, p_quantity integer
) RETURNS text LANGUAGE plpgsql AS $$
DECLARE
  inserted integer;
  previous blog_order_demo.reservations%ROWTYPE;
BEGIN
  IF p_request IS NULL OR p_request = '' OR p_quantity IS NULL OR p_quantity <= 0 THEN
    RAISE EXCEPTION 'invalid reservation request';
  END IF;

  INSERT INTO blog_order_demo.reservations(request_id, sku, quantity)
    VALUES (p_request, p_sku, p_quantity)
    ON CONFLICT (request_id) DO NOTHING;
  GET DIAGNOSTICS inserted = ROW_COUNT;

  IF inserted = 0 THEN
    SELECT * INTO STRICT previous FROM blog_order_demo.reservations
      WHERE request_id = p_request;
    IF previous.sku IS DISTINCT FROM p_sku OR previous.quantity <> p_quantity THEN
      RAISE EXCEPTION 'request_id reused with different input';
    END IF;
    RETURN 'replayed';
  END IF;

  UPDATE blog_order_demo.inventory
    SET available = available - p_quantity, version = version + 1
    WHERE sku = p_sku AND available >= p_quantity;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'insufficient stock';
  END IF;
  RETURN 'created';
END;
$$;

-- Session A:
-- BEGIN;
-- SELECT blog_order_demo.reserve('request-a', 'demo-widget', 1);
-- Keep A open while running session B, then COMMIT;

-- Session B:
-- BEGIN;
-- SELECT blog_order_demo.reserve('request-b', 'demo-widget', 1);
-- Waits for A, then expected ERROR insufficient stock if A commits.
-- ROLLBACK;

-- Expected committed state after A COMMIT and B ROLLBACK:
-- SELECT available, version FROM blog_order_demo.inventory; -- 0, 1
-- SELECT count(*) FROM blog_order_demo.reservations; -- 1
-- SELECT blog_order_demo.reserve('request-a', 'demo-widget', 1); -- replayed
