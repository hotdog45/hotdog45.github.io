import assert from 'node:assert/strict';
function makeSaveAction(save, onOptimistic = () => {}) {
  return async function action(previous, formData) {
    if (!formData || typeof formData.get !== 'function') {
      return { kind: 'invalid', message: '表单结构错误' };
    }
    const rawName = formData.get('name');
    const rawKey = formData.get('requestKey');
    if (typeof rawName !== 'string' || typeof rawKey !== 'string') {
      return { kind: 'invalid', message: '请检查输入类型' };
    }
    const name = rawName.trim(), requestKey = rawKey.trim();
    if (!name || name.length > 80
        || !/^[a-zA-Z0-9_-]{8,128}$/.test(requestKey)) {
      return { kind: 'invalid', message: '请检查姓名和操作标识' };
    }
    onOptimistic({ name, requestKey });
    try {
      const receipt = await save({ name, requestKey });
      if (!receipt || typeof receipt.id !== 'string' || !receipt.id) {
        return { kind: 'uncertain', message: '结果未确认，请用同一操作重试' };
      }
      return { kind: 'saved', receipt: { id: receipt.id, name, requestKey } };
    } catch (error) {
      if (error && error.code === 'version_conflict') {
        return { kind: 'conflict', message: '资料已有更新，请先核对' };
      }
      if (error && error.code === 'request_conflict') {
        return { kind: 'request_conflict', message: '操作标识已用于其他内容，请核对' };
      }
      return { kind: 'uncertain', message: '结果未确认，请用同一操作重试' };
    }
  };
}

const form = entries => ({ get: key => entries[key] ?? null });
let calls = 0;
const optimistic = [];
const valid = form({ name: ' Demo ', requestKey: 'request_0001' });
const action = makeSaveAction(async input => { calls++; return { id: 'receipt-1' }; }, x => optimistic.push(x));
assert.equal((await action(null, valid)).receipt.name, 'Demo');
assert.equal(calls, 1);
assert.equal((await action(null, form({ name: '', requestKey: 'request_0001' }))).kind, 'invalid');
assert.equal(calls, 1);
assert.equal((await action(null, form({ name: {}, requestKey: 'request_0001' }))).kind, 'invalid');
assert.equal((await action(null, null)).kind, 'invalid');
const conflict = makeSaveAction(async () => { throw Object.assign(new Error('private detail'), { code: 'version_conflict' }); });
assert.equal((await conflict(null, valid)).kind, 'conflict');
let accepts = 0, attempts = 0;
const receipts = new Map();
const uncertain = makeSaveAction(async input => {
  attempts++;
  if (!receipts.has(input.requestKey)) { accepts++; receipts.set(input.requestKey, { id: 'accepted-1' }); }
  if (attempts === 1) throw new Error('response lost');
  return receipts.get(input.requestKey);
});
assert.equal((await uncertain(null, valid)).kind, 'uncertain');
assert.equal((await uncertain(null, valid)).kind, 'saved');
assert.equal(accepts, 1);
const malformed = makeSaveAction(async () => ({}));
assert.equal((await malformed(null, valid)).kind, 'uncertain');
assert.equal(optimistic.length, 1);
console.log('8 action behavior groups passed; no React19 renderer,form reset or optimistic lifecycle tested');
