function beginLoad(id, load, publish) {
  let active = true;
  publish({ id, status: 'loading', data: null, error: null });
  const done = Promise.resolve().then(() => load(id)).then(
    data => {
      if (active) publish({ id, status: 'success', data, error: null });
    },
    () => {
      if (active) publish({ id, status: 'error', data: null, error: 'load_failed' });
    }
  );
  return {
    done,
    cleanup() { active = false; }
  };
}

import { useEffect, useState } from 'react';

function useResource(id, load) {
  const [state, setState] = useState({
    id, status: 'loading', data: null, error: null
  });
  useEffect(() => {
    const operation = beginLoad(id, load, setState);
    return operation.cleanup;
  }, [id, load]);
  return state.id === id ? state : {
    id, status: 'loading', data: null, error: null
  };
}
