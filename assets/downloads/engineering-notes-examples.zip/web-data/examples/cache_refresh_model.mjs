import assert from 'node:assert/strict';

class Store {
  constructor() { this.time = 0; this.items = new Map(); }
  get(key) {
    const entry = this.items.get(key);
    if (!entry || entry.expires <= this.time) { this.items.delete(key); return null; }
    return entry.value;
  }
  set(key, value, ttl) { this.items.set(key, { value, expires: this.time + ttl }); }
  acquire(key, token, ttl) {
    if (this.get(key) !== null) return false;
    this.set(key, token, ttl); return true;
  }
  publish(lock, cache, token, value, ttl) {
    if (this.get(lock) !== token) return false;
    this.set(cache, value, ttl); this.items.delete(lock); return true;
  }
  release(lock, token) {
    if (this.get(lock) !== token) return false;
    this.items.delete(lock); return true;
  }
}

const store = new Store();
const accepted = Array.from({ length: 20 }, (_, i) => store.acquire('lock', 'token-' + i, 100));
assert.equal(accepted.filter(Boolean).length, 1);
store.time = 101;
assert.equal(store.acquire('lock', 'new-owner', 100), true);
assert.equal(store.release('lock', 'token-0'), false);
assert.equal(store.publish('lock', 'cache', 'token-0', 'old', 1000), false);
assert.equal(store.publish('lock', 'cache', 'new-owner', 'fresh', 1000), true);
assert.equal(store.get('cache'), 'fresh');
store.time = 1101;
assert.equal(store.get('cache'), null);
const base = 1000, maxJitter = 200;
for (const random of [0, 0.25, 0.99]) {
  const ttl = base + Math.floor(random * maxJitter);
  assert.ok(ttl >= base && ttl < base + maxJitter);
}
console.log('8 cache-refresh model checks passed; no Redis, Lua or failover execution tested');
