import assert from 'node:assert/strict';

export function page(rows, tenant, status, limit, cursor = null) {
  if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new Error('invalid limit');
  if (cursor && (cursor.tenant !== tenant || cursor.status !== status)) throw new Error('cursor scope');
  const before = row => !cursor || row.created < cursor.created ||
    (row.created === cursor.created && BigInt(row.id) < BigInt(cursor.id));
  const sorted = rows.filter(r => r.tenant === tenant && r.status === status && before(r))
    .sort((a, b) => a.created > b.created ? -1 : a.created < b.created ? 1 :
      BigInt(a.id) > BigInt(b.id) ? -1 : BigInt(a.id) < BigInt(b.id) ? 1 : 0);
  const items = sorted.slice(0, limit);
  const last = items[items.length - 1];
  return { items, next: last ? { tenant, status, created: last.created, id: last.id } : null };
}

const rows = [
  { id: '9007199254740995', tenant: 'a', status: 'open', created: '2016-05-01 10:00:00.000001' },
  { id: '9007199254740994', tenant: 'a', status: 'open', created: '2016-05-01 10:00:00.000001' },
  { id: '9007199254740993', tenant: 'a', status: 'open', created: '2016-05-01 09:00:00.000001' },
  { id: '12', tenant: 'b', status: 'open', created: '2016-05-01 11:00:00.000001' },
  { id: '11', tenant: 'a', status: 'closed', created: '2016-05-01 11:00:00.000001' }
];
const first = page(rows, 'a', 'open', 1);
assert.equal(first.items[0].id, '9007199254740995');
const second = page(rows, 'a', 'open', 1, first.next);
assert.equal(second.items[0].id, '9007199254740994');
const third = page(rows, 'a', 'open', 1, second.next);
assert.equal(third.items[0].id, '9007199254740993');
assert.equal(page(rows, 'a', 'open', 1, third.next).items.length, 0);
assert.equal(new Set([...first.items, ...second.items, ...third.items].map(r => r.id)).size, 3);
const added = [...rows, { id: '99', tenant: 'a', status: 'open', created: '2016-05-01 12:00:00.000001' }];
assert.equal(page(added, 'a', 'open', 1, first.next).items[0].id, second.items[0].id);
const deletedAnchor = rows.filter(r => r.id !== first.items[0].id);
assert.equal(page(deletedAnchor, 'a', 'open', 1, first.next).items[0].id, second.items[0].id);
assert.throws(() => page(rows, 'b', 'open', 1, first.next), /cursor scope/);
assert.throws(() => page(rows, 'a', 'open', 0), /invalid limit/);
console.log('7 keyset model checks passed; no MySQL optimizer or SQL execution tested');
