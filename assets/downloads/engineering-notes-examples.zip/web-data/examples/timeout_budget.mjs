import assert from 'node:assert/strict';

export function timeoutBudget(deadline, now, cap, reserve) {
  if (![deadline, now, cap, reserve].every(Number.isFinite) || cap <= 0 || reserve < 0) {
    throw new Error('invalid budget');
  }
  const available = deadline - now - reserve;
  if (available <= 0) throw new Error('deadline exhausted');
  return Math.min(cap, available);
}
export function gatewayDeadline(incoming, now, cap, trusted = false) {
  if (!Number.isFinite(now) || !Number.isFinite(cap) || cap <= 0) throw new Error('invalid gateway');
  return trusted && Number.isFinite(incoming) ? Math.min(incoming, now + cap) : now + cap;
}
export function childDeadline(parent, now, cap) {
  return Math.min(parent, now + timeoutBudget(parent, now, cap, 0));
}

assert.equal(timeoutBudget(200, 0, 100, 20), 100);
assert.equal(timeoutBudget(200, 80, 500, 20), 100);
assert.equal(timeoutBudget(200, 160, 100, 20), 20);
assert.throws(() => timeoutBudget(200, 201, 100, 0), /exhausted/);
assert.throws(() => timeoutBudget(200, 185, 100, 20), /exhausted/);
assert.equal(childDeadline(200, 180, 100), 200);
assert.equal(gatewayDeadline(99999, 10, 200, false), 210);
assert.equal(gatewayDeadline(99999, 10, 200, true), 210);
assert.throws(() => timeoutBudget(200, 0, -1, 0), /invalid/);
console.log('9 deadline-budget checks passed; no OpenTelemetry SDK, clocksync or network integration tested');
