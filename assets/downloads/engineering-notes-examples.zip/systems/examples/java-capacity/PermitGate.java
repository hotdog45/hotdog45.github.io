import java.util.concurrent.Callable;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public final class PermitGate {
    private final Semaphore permits;
    public PermitGate(int maximum) { permits = new Semaphore(maximum, true); }
    public <T> T call(long waitMillis, Callable<T> work) throws Exception {
        if (!permits.tryAcquire(waitMillis, TimeUnit.MILLISECONDS)) {
            throw new RejectedExecutionException("dependency capacity exhausted");
        }
        try { return work.call(); }
        finally { permits.release(); }
    }
    int available() { return permits.availablePermits(); }
}
