import java.util.concurrent.*;

public final class PermitGateTest {
    public static void main(String[] args) throws Exception {
        PermitGate gate = new PermitGate(2);
        ExecutorService platformThreads = Executors.newFixedThreadPool(2);
        CountDownLatch entered = new CountDownLatch(2);
        CountDownLatch release = new CountDownLatch(1);
        Callable<Integer> holding = () -> gate.call(1000, () -> {
            entered.countDown();
            if (!release.await(2, TimeUnit.SECONDS)) throw new AssertionError("release timed out");
            return 1;
        });
        try {
            Future<Integer> first = platformThreads.submit(holding);
            Future<Integer> second = platformThreads.submit(holding);
            if (!entered.await(2, TimeUnit.SECONDS)) throw new AssertionError("not occupied");
            try { gate.call(0, () -> 3); throw new AssertionError("capacity not enforced"); }
            catch (RejectedExecutionException expected) { }
            release.countDown();
            first.get(2, TimeUnit.SECONDS); second.get(2, TimeUnit.SECONDS);
            try { gate.call(0, () -> { throw new Exception("dependency failed"); }); }
            catch (Exception expected) {
                if (!"dependency failed".equals(expected.getMessage())) throw expected;
            }
            if (gate.available() != 2) throw new AssertionError("permit leaked");
            if (gate.call(0, () -> 7) != 7) throw new AssertionError("recovery failed");
            System.out.println("PASS: capacity rejection, release, exception cleanup, recovery (platform threads only)");
        } finally {
            release.countDown();
            platformThreads.shutdownNow();
            if (!platformThreads.awaitTermination(2, TimeUnit.SECONDS)) throw new AssertionError("cleanup failed");
        }
    }
}
