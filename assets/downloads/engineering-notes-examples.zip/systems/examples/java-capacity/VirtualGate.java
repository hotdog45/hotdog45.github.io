// Requires JDK21. Reviewed against official API; not executed on the local JDK11.
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public final class VirtualGate {
    public static void main(String[] args) throws Exception {
        PermitGate database = new PermitGate(2);
        try (ExecutorService tasks = Executors.newVirtualThreadPerTaskExecutor()) {
            List<Future<String>> results = new ArrayList<>();
            for (int i = 0; i < 8; i++) {
                final int row = i;
                results.add(tasks.submit(() -> database.call(100, () -> "fixture-row-" + row)));
            }
            for (Future<String> result : results) System.out.println(result.get());
        }
    }
}
