import tempfile
import unittest
from pathlib import Path
from workflow import Crash, Provider, Workflow


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.p = Path(self.tmp.name)
        self.provider = Provider(self.p / 'provider.sqlite')
        self.w = Workflow(self.p / 'flow.sqlite', self.provider)
        self.digest = self.w.start('job-7', {'resource': 'fixture-room'}, expires=100)

    def tearDown(self):
        self.w.close()
        self.provider.close()
        self.tmp.cleanup()

    def approve(self):
        return self.w.approve('job-7', self.digest, 1, 'fixture-reviewer', now=10)

    def restart(self):
        self.w.close()
        self.provider.close()
        self.provider = Provider(self.p / 'provider.sqlite')
        self.w = Workflow(self.p / 'flow.sqlite', self.provider)

    def test_wait_and_approval_survive_restart(self):
        self.restart()
        self.assertEqual(self.w.advance('job-7'), 'WAIT_APPROVAL')
        self.assertEqual(self.provider.db.execute('SELECT count(*) FROM effects').fetchone()[0], 0)
        self.approve()
        self.restart()
        self.assertEqual(self.w.advance('job-7'), 'ACTIVATE_PENDING')
        self.assertEqual(self.w.advance('job-7'), 'DONE')

    def test_stale_changed_unauthorized_and_expired_approval(self):
        with self.assertRaises(ValueError):
            self.w.start('job-7', {'resource': 'another-room'}, expires=100)
        with self.assertRaises(ValueError):
            self.w.approve('job-7', self.digest, 2, 'fixture-reviewer', 10)
        with self.assertRaises(PermissionError):
            self.w.approve('job-7', self.digest, 1, 'model', 10)
        self.assertEqual(self.w.approve('job-7', self.digest, 1, 'fixture-reviewer', 100), 'EXPIRED')
        self.assertEqual(self.w.advance('job-7'), 'EXPIRED')

    def test_crash_after_reservation_does_not_duplicate_effect(self):
        self.approve()
        with self.assertRaises(Crash):
            self.w.advance('job-7', crash_after_reserve=True)
        self.assertEqual(self.w.row('job-7')['state'], 'RESERVE_PENDING')
        self.restart()
        self.assertEqual(self.w.advance('job-7'), 'ACTIVATE_PENDING')
        self.assertEqual(self.provider.db.execute('SELECT count(*) FROM effects').fetchone()[0], 1)

    def test_failed_compensation_remains_pending_then_recovers(self):
        self.approve()
        self.w.advance('job-7')
        self.provider.fail_activation = True
        self.assertEqual(self.w.advance('job-7'), 'COMPENSATE_PENDING')
        self.provider.fail_release = True
        with self.assertRaises(ConnectionError):
            self.w.advance('job-7')
        self.restart()
        self.assertEqual(self.w.row('job-7')['state'], 'COMPENSATE_PENDING')
        self.assertEqual(self.w.advance('job-7'), 'CANCELLED')
        self.assertEqual(self.provider.status('job-7:reserve:v1'), 'released')

    def test_unknown_activation_is_reconciled_without_compensation(self):
        self.approve()
        self.w.advance('job-7')
        self.provider.lose_activation_reply = True
        self.assertEqual(self.w.advance('job-7'), 'RECONCILE')
        self.provider.lookup_available = False
        self.assertEqual(self.w.advance('job-7'), 'RECONCILE')
        self.restart()
        self.assertEqual(self.w.advance('job-7'), 'DONE')
        self.assertEqual(self.provider.status('job-7:reserve:v1'), 'active')

    def test_terminal_replay_preserves_history_and_other_flows(self):
        self.approve()
        self.w.advance('job-7')
        self.w.advance('job-7')
        n = self.w.db.execute('SELECT count(*) FROM history').fetchone()[0]
        for _ in range(3):
            self.assertEqual(self.w.advance('job-7'), 'DONE')
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM history').fetchone()[0], n)
        self.w.start('job-8', {'resource': 'fixture-room'}, expires=100)
        self.assertEqual(self.w.advance('job-8'), 'WAIT_APPROVAL')


if __name__ == '__main__':
    unittest.main()
