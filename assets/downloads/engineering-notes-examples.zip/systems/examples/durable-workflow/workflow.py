"""Single-worker, local two-database workflow model; no remote services."""
import hashlib
import json
import sqlite3


class Crash(Exception):
    pass


class Provider:
    """Trusted fixture provider, whose operation keys survive engine restarts."""
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute("CREATE TABLE IF NOT EXISTS effects (op TEXT PRIMARY KEY, status TEXT)")
        self.fail_activation = False
        self.lose_activation_reply = False
        self.lookup_available = True
        self.fail_release = False

    def status(self, op):
        if not self.lookup_available:
            raise ConnectionError("provider status unavailable")
        row = self.db.execute("SELECT status FROM effects WHERE op=?", (op,)).fetchone()
        return row[0] if row else None

    def reserve(self, op):
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO effects VALUES (?, 'reserved')", (op,))

    def activate(self, op):
        observed = self.status(op)
        if observed == 'active':
            return 'active'
        if observed != 'reserved':
            raise RuntimeError('activation requires a known reservation')
        if self.fail_activation:
            return "rejected"  # Fixture contract: definitely no activation occurred.
        with self.db:
            self.db.execute("UPDATE effects SET status='active' WHERE op=? AND status='reserved'", (op,))
        if self.lose_activation_reply:
            raise TimeoutError("reply lost after durable provider effect")
        return "active"

    def release(self, op):
        if self.fail_release:
            raise ConnectionError("release unavailable")
        with self.db:
            # Compensate only this workflow's reservation, never an active resource.
            self.db.execute("UPDATE effects SET status='released' WHERE op=? AND status='reserved'", (op,))
        if self.status(op) != "released":
            raise RuntimeError("cannot compensate an active/unknown resource")

    def close(self):
        self.db.close()


class Workflow:
    def __init__(self, path, provider):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.provider = provider
        self.db.execute("""CREATE TABLE IF NOT EXISTS flows (
            id TEXT PRIMARY KEY, spec_hash TEXT NOT NULL, revision INTEGER NOT NULL,
            state TEXT NOT NULL, expires INTEGER NOT NULL,
            approver TEXT, note TEXT NOT NULL DEFAULT '')""")
        self.db.execute("""CREATE TABLE IF NOT EXISTS history (
            seq INTEGER PRIMARY KEY, flow TEXT, state TEXT, note TEXT)""")

    def row(self, flow):
        row = self.db.execute("SELECT * FROM flows WHERE id=?", (flow,)).fetchone()
        if row is None:
            raise KeyError(flow)
        return row

    def _state(self, flow, state, note=""):
        self.db.execute("UPDATE flows SET state=?, note=? WHERE id=?", (state, note, flow))
        self.db.execute("INSERT INTO history(flow,state,note) VALUES(?,?,?)", (flow, state, note))

    def start(self, flow, spec, expires):
        digest = hashlib.sha256(json.dumps(spec, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        with self.db:
            old = self.db.execute("SELECT spec_hash FROM flows WHERE id=?", (flow,)).fetchone()
            if old:
                if old[0] != digest:
                    raise ValueError("workflow input changed; use a new revision/id and approval")
                return digest
            self.db.execute("INSERT INTO flows(id,spec_hash,revision,state,expires) VALUES(?,?,1,'WAIT_APPROVAL',?)",
                            (flow, digest, expires))
            self.db.execute("INSERT INTO history(flow,state,note) VALUES(?,'WAIT_APPROVAL','created')", (flow,))
        return digest

    def approve(self, flow, spec_hash, revision, actor, now):
        # actor comes from authenticated host identity, never a model argument.
        if actor not in {"fixture-reviewer"}:
            raise PermissionError("reviewer required")
        with self.db:
            row = self.row(flow)
            if row['state'] != 'WAIT_APPROVAL' or row['spec_hash'] != spec_hash or row['revision'] != revision:
                raise ValueError("stale approval")
            if now >= row['expires']:
                self._state(flow, "EXPIRED", "approval deadline")
                return "EXPIRED"
            self.db.execute("UPDATE flows SET approver=? WHERE id=?", (actor, flow))
            self._state(flow, "RESERVE_PENDING", "approved exact revision")
        return "RESERVE_PENDING"

    def advance(self, flow, crash_after_reserve=False):
        row = self.row(flow)
        state, op = row['state'], flow + ':reserve:v1'
        if state == 'RESERVE_PENDING':
            self.provider.reserve(op)
            if crash_after_reserve:
                raise Crash("provider committed, engine has not acknowledged")
            with self.db:
                self._state(flow, 'ACTIVATE_PENDING', 'reservation observed')
        elif state == 'ACTIVATE_PENDING':
            try:
                result = self.provider.activate(op)
            except TimeoutError:
                with self.db:
                    self._state(flow, 'RECONCILE', 'activation outcome unknown; do not compensate')
                return self.row(flow)['state']
            with self.db:
                self._state(flow, 'DONE' if result == 'active' else 'COMPENSATE_PENDING', result)
        elif state == 'RECONCILE':
            try:
                observed = self.provider.status(op)
            except ConnectionError:
                return state
            with self.db:
                if observed == 'active':
                    self._state(flow, 'DONE', 'provider status confirmed active')
                # None/reserved is intentionally not assumed safe after an uncertain activation.
        elif state == 'COMPENSATE_PENDING':
            self.provider.release(op)  # Failure leaves durable state pending; operator can retry.
            with self.db:
                self._state(flow, 'CANCELLED', 'owned reservation released')
        return self.row(flow)['state']

    def close(self):
        self.db.close()
