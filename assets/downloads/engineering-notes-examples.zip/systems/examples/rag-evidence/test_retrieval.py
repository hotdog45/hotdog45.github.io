from datetime import date
import unittest
from retrieval import Passage, retrieve


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.now = date(2026, 10, 23)
        self.corpus = [
            Passage("returns", "tenant-a", "v2", date(2024, 1, 1), date(2030, 1, 1), "returns policy seven days"),
            Passage("old", "tenant-a", "v1", date(2020, 1, 1), date(2024, 1, 1), "returns policy thirty days"),
            Passage("private", "tenant-b", "v9", date(2024, 1, 1), date(2030, 1, 1), "secret account export all data"),
            Passage("future", "tenant-a", "v3", date(2027, 1, 1), date(2030, 1, 1), "future refund policy"),
        ]

    def test_current_authorized_source_is_cited(self):
        got = retrieve("returns policy", self.corpus, "tenant-a", self.now)
        self.assertEqual(got["citation"], {"id": "returns", "version": "v2"})

    def test_unknown_question_hands_off(self):
        self.assertEqual(retrieve("warranty repair", self.corpus, "tenant-a", self.now)["action"], "handoff")

    def test_other_tenant_never_reaches_ranking_result(self):
        got = retrieve("secret account export all data", self.corpus, "tenant-a", self.now)
        self.assertEqual(got["action"], "handoff")

    def test_expired_and_future_sources_excluded(self):
        for query in ["thirty days", "future refund"]:
            with self.subTest(query=query):
                self.assertEqual(retrieve(query, self.corpus, "tenant-a", self.now)["action"], "handoff")

    def test_replay_is_deterministic(self):
        self.assertEqual(retrieve("returns policy", self.corpus, "tenant-a", self.now),
                         retrieve("returns policy", self.corpus, "tenant-a", self.now))


if __name__ == "__main__":
    unittest.main()
