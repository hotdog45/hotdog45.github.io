"""Deterministic retrieval boundary model. No embeddings or generation."""
from dataclasses import dataclass
from datetime import date
import re


@dataclass(frozen=True)
class Passage:
    id: str
    tenant: str
    version: str
    start: date
    end: date
    text: str


def tokens(text):
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def retrieve(query, corpus, authorized_tenant, as_of, minimum_overlap=2):
    # authorized_tenant must come from server authentication, not the question.
    eligible = [p for p in corpus if p.tenant == authorized_tenant
                and p.start <= as_of < p.end]
    query_tokens = tokens(query)
    ranked = sorted(((len(query_tokens & tokens(p.text)), p.id, p) for p in eligible),
                    key=lambda row: (-row[0], row[1]))
    if not ranked or ranked[0][0] < minimum_overlap:
        return {"action": "handoff", "reason": "insufficient_evidence"}
    score, _, passage = ranked[0]
    return {"action": "evidence", "passage": passage.text,
            "citation": {"id": passage.id, "version": passage.version},
            "score": score}
