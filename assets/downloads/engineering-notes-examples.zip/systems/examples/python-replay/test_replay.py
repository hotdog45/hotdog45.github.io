import tempfile
import unittest
from pathlib import Path
from replay import connect, apply


class ReplayTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "jobs.sqlite"
        self.db = connect(self.path)

    def tearDown(self):
        self.db.close()
        self.tmp.cleanup()

    def test_replay_does_not_duplicate_effect(self):
        first = apply(self.db, "batch-1", [2, 3])
        again = apply(self.db, "batch-1", [2, 3])
        self.assertFalse(first["replayed"])
        self.assertTrue(again["replayed"])
        self.assertEqual(first["result"], again["result"])
        self.assertEqual(self.db.execute("SELECT count(*) FROM outputs").fetchone()[0], 1)

    def test_different_payload_conflicts(self):
        apply(self.db, "batch-1", [2, 3])
        with self.assertRaisesRegex(ValueError, "different input"):
            apply(self.db, "batch-1", [9])
        self.assertEqual(self.db.execute("SELECT total FROM outputs").fetchone()[0], 5)

    def test_failure_rolls_back_output_and_receipt(self):
        with self.assertRaisesRegex(RuntimeError, "interruption"):
            apply(self.db, "batch-1", [2], fail_before_commit=True)
        self.assertEqual(self.db.execute("SELECT count(*) FROM outputs").fetchone()[0], 0)
        self.assertEqual(self.db.execute("SELECT count(*) FROM receipts").fetchone()[0], 0)
        self.assertFalse(apply(self.db, "batch-1", [2])["replayed"])

    def test_receipt_survives_reopening(self):
        apply(self.db, "batch-1", [2])
        self.db.close()
        self.db = connect(self.path)
        self.assertTrue(apply(self.db, "batch-1", [2])["replayed"])

    def test_bad_input_has_no_effect(self):
        for value in [[-1], [True], "2"]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                apply(self.db, "bad", value)
        self.assertEqual(self.db.execute("SELECT count(*) FROM receipts").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main()
