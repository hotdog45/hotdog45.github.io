import sqlite3
import tempfile
from pathlib import Path
import unittest
from batch import run_batch


class BatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.source = self.root / "input.csv"
        self.source.write_text("job_id,quantity\nalpha,2\nbeta,broken\ngamma,3\n")
        self.state = self.root / "state"

    def tearDown(self):
        self.tmp.cleanup()

    def test_bad_row_is_isolated_and_counted(self):
        got = run_batch(self.source, self.state)
        self.assertEqual((got["done"], got["rejected"], got["retryable"], got["total"]), (2, 1, 0, 3))
        self.assertTrue(got["all_rows_terminal"])
        self.assertFalse(got["batch_complete"])
        with sqlite3.connect(str(self.state / "batch.sqlite")) as db:
            self.assertEqual(db.execute("SELECT kind FROM failures").fetchall(), [("rejected",)])

    def test_interrupted_batch_resumes_without_duplicate_output(self):
        with self.assertRaisesRegex(RuntimeError, "batch interruption"):
            run_batch(self.source, self.state, interrupt_after=1)
        got = run_batch(self.source, self.state)
        self.assertEqual((got["done"], got["replayed"]), (2, 1))
        with sqlite3.connect(str(self.state / "batch.sqlite")) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM outputs").fetchone()[0], 2)

    def test_changed_source_is_rejected_before_more_work(self):
        run_batch(self.source, self.state)
        self.source.write_text(self.source.read_text() + "delta,4\n")
        with self.assertRaisesRegex(ValueError, "source changed"):
            run_batch(self.source, self.state)
        with sqlite3.connect(str(self.state / "batch.sqlite")) as db:
            self.assertEqual(db.execute("SELECT count(*) FROM outputs").fetchone()[0], 2)

    def test_duplicate_keys_are_all_rejected(self):
        self.source.write_text("job_id,quantity\nalpha,2\nalpha,3\n")
        got = run_batch(self.source, self.state)
        self.assertEqual((got["done"], got["rejected"]), (0, 2))

    def test_temporary_failure_does_not_claim_complete(self):
        got = run_batch(self.source, self.state, fail_job="alpha")
        self.assertFalse(got["batch_complete"])
        self.assertEqual(got["retryable"], 1)
        final = run_batch(self.source, self.state)
        self.assertTrue(final["all_rows_terminal"])
        self.assertFalse(final["batch_complete"])  # An invalid row still needs review.


if __name__ == "__main__":
    unittest.main()
