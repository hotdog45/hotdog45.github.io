"""Single-operator CSV batch recovery model, local database only."""
from collections import Counter
import csv
import hashlib
import io
from pathlib import Path
from replay import connect, apply


def run_batch(source, state_dir, interrupt_after=None, fail_job=None):
    state_dir = Path(state_dir)
    state_dir.mkdir(parents=True, exist_ok=True)
    raw = Path(source).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    db = connect(state_dir / "batch.sqlite")
    try:
        db.executescript("""
          CREATE TABLE IF NOT EXISTS manifest(
            id INTEGER PRIMARY KEY CHECK(id=1), digest TEXT NOT NULL, raw_csv BLOB NOT NULL);
          CREATE TABLE IF NOT EXISTS failures(
            event_id INTEGER PRIMARY KEY AUTOINCREMENT, record_key TEXT NOT NULL,
            kind TEXT NOT NULL, reason TEXT NOT NULL);
        """)
        previous = db.execute("SELECT digest FROM manifest WHERE id=1").fetchone()
        if previous and previous[0] != digest:
            raise ValueError("source changed; create a new batch or review the difference")
        if not previous:
            db.execute("INSERT INTO manifest VALUES (1,?,?)", (digest, raw))
        reader = csv.DictReader(io.StringIO(raw.decode("utf-8")))
        if reader.fieldnames != ["job_id", "quantity"]:
            raise ValueError("invalid CSV header")
        rows = list(reader)
        keys = Counter((row.get("job_id") or "").strip() for row in rows)
        counts = {"done": 0, "replayed": 0, "rejected": 0, "retryable": 0}
        completed_calls = 0
        for line, row in enumerate(rows, start=2):
            job_id = (row.get("job_id") or "").strip()
            try:
                if None in row or row.get("quantity") is None:
                    raise ValueError("malformed CSV row")
                if not job_id or keys[job_id] != 1:
                    raise ValueError("missing or duplicated stable job key")
                quantity = int(row.get("quantity") or "")
                if not 0 <= quantity <= 2**63 - 1:
                    raise ValueError("quantity outside SQLite integer range")
            except (ValueError, TypeError) as error:
                db.execute("INSERT INTO failures(record_key,kind,reason) VALUES (?,?,?)",
                           ("line:" + str(line), "rejected", str(error)))
                counts["rejected"] += 1
                continue
            try:
                if job_id == fail_job:
                    raise RuntimeError("injected temporary failure")
                receipt = apply(db, job_id, [quantity])
                counts["done"] += 1
                counts["replayed"] += int(receipt["replayed"])
            except RuntimeError as error:
                db.execute("INSERT INTO failures(record_key,kind,reason) VALUES (?,?,?)",
                           (job_id, "retryable", str(error)))
                counts["retryable"] += 1
                continue
            completed_calls += 1
            if interrupt_after is not None and completed_calls >= interrupt_after:
                raise RuntimeError("injected batch interruption")
        counts.update(total=len(rows), pending=0, snapshot_sha256=digest,
                      all_rows_terminal=counts["retryable"] == 0,
                      batch_complete=counts["retryable"] == 0 and counts["rejected"] == 0)
        assert counts["done"] + counts["rejected"] + counts["retryable"] == counts["total"]
        return counts
    finally:
        db.close()
