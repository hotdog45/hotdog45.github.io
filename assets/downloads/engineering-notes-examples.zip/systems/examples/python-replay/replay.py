"""SQLite-local effects + receipts share one transaction; no external calls."""
import hashlib
import json
import sqlite3


def connect(path):
    db = sqlite3.connect(str(path), isolation_level=None)
    db.executescript("""
      CREATE TABLE IF NOT EXISTS receipts(
        job_id TEXT PRIMARY KEY, digest TEXT NOT NULL, result TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS outputs(
        job_id TEXT PRIMARY KEY, total INTEGER NOT NULL CHECK(total >= 0));
    """)
    return db


def apply(db, job_id, quantities, fail_before_commit=False):
    if not isinstance(job_id, str) or not job_id:
        raise ValueError("job_id is required")
    if not isinstance(quantities, list) or not all(
        type(n) is int and n >= 0 for n in quantities
    ):
        raise ValueError("quantities must be nonnegative integers")
    canonical = json.dumps(quantities, separators=(",", ":"))
    digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    db.execute("BEGIN IMMEDIATE")
    try:
        previous = db.execute(
            "SELECT digest, result FROM receipts WHERE job_id=?", (job_id,)
        ).fetchone()
        if previous:
            if previous[0] != digest:
                raise ValueError("same job_id, different input")
            db.execute("COMMIT")
            return {"replayed": True, "result": json.loads(previous[1])}
        result = {"total": sum(quantities)}
        db.execute("INSERT INTO outputs VALUES (?,?)", (job_id, result["total"]))
        if fail_before_commit:
            raise RuntimeError("injected interruption")
        db.execute("INSERT INTO receipts VALUES (?,?,?)",
                   (job_id, digest, json.dumps(result, sort_keys=True)))
        db.execute("COMMIT")
        return {"replayed": False, "result": result}
    except BaseException:
        if db.in_transaction:
            db.execute("ROLLBACK")
        raise
