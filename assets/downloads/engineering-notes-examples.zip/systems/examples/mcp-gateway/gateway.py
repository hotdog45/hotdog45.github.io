"""Offline authorization model, not an MCP transport or OAuth implementation."""
import hashlib
import json
import re


class Gateway:
    def __init__(self):
        self.notes = {("tenant-a", "public"): "fixture note",
                      ("tenant-b", "private"): "other tenant"}
        self.approvals = {}

    @staticmethod
    def fingerprint(principal, tool, arguments):
        data = [principal["user"], principal["tenant"], tool, arguments]
        return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()

    def record_user_approval(self, key, principal, tool, arguments, expires):
        # Called only by trusted host UI after user confirmation; never exposed
        # as a model tool. A production store must consume atomically/durably.
        self.approvals[key] = {"digest": self.fingerprint(principal, tool, arguments),
                               "expires": expires, "used": False}

    def invoke(self, tool, arguments, principal, approval_id=None, now=0):
        registry = {"notes.read": ({"id"}, "notes:read"),
                    "notes.add": ({"id", "text"}, "notes:write")}
        if tool not in registry:
            raise PermissionError("unknown tool")
        fields, scope = registry[tool]
        if not isinstance(arguments, dict) or set(arguments) != fields:
            raise ValueError("unexpected or missing argument")
        if not isinstance(arguments["id"], str) or not re.fullmatch(r"[a-z0-9-]{1,40}", arguments["id"]):
            raise ValueError("invalid note identifier")
        if scope not in principal["scopes"]:
            raise PermissionError("missing scope")
        key = (principal["tenant"], arguments["id"])
        if tool == "notes.read":
            if key not in self.notes:
                raise KeyError("note not found")
            return {"text": self.notes[key]}
        if not isinstance(arguments["text"], str) or not 1 <= len(arguments["text"]) <= 80:
            raise ValueError("invalid text length")
        approval = self.approvals.get(approval_id)
        digest = self.fingerprint(principal, tool, arguments)
        if not approval or approval["used"] or approval["expires"] <= now or approval["digest"] != digest:
            raise PermissionError("specific approval required")
        if key in self.notes:
            raise ValueError("note already exists")
        approval["used"] = True
        self.notes[key] = arguments["text"]
        return {"id": arguments["id"], "status": "created"}
