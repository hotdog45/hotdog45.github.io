"""Local POSIX release-pointer model; never deploys to a server."""
import fcntl
import hashlib
import os
from pathlib import Path
import re
import uuid


def release(root, version, content):
    if not re.fullmatch(r"[a-z0-9-]+", version):
        raise ValueError("invalid version")
    directory = Path(root) / "releases" / version
    directory.mkdir(parents=True, exist_ok=False)
    artifact = content.encode("utf-8")
    (directory / "index.txt").write_bytes(artifact)
    digest = hashlib.sha256(artifact).hexdigest()
    (directory / "sha256").write_text(digest)
    return version


def replace_pointer(root, target):
    temporary = root / (".next-" + uuid.uuid4().hex)
    try:
        temporary.symlink_to(target)
        os.replace(str(temporary), str(root / "current"))
    finally:
        if temporary.is_symlink():
            temporary.unlink()


def activate(root, version, expected_previous, smoke):
    root = Path(root)
    if not re.fullmatch(r"[a-z0-9-]+", version):
        raise ValueError("invalid version")
    with (root / ".deploy.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        current = root / "current"
        previous = os.readlink(str(current)) if current.is_symlink() else None
        if previous != expected_previous:
            raise RuntimeError("stale deployment intent")
        directory = root / "releases" / version
        actual = hashlib.sha256((directory / "index.txt").read_bytes()).hexdigest()
        if actual != (directory / "sha256").read_text():
            raise ValueError("artifact hash mismatch")
        replace_pointer(root, "releases/" + version)
        try:
            if not smoke(current):
                raise RuntimeError("smoke check failed")
        except BaseException:
            if previous is None:
                current.unlink()
            else:
                replace_pointer(root, previous)
            raise
        return {"active": version, "previous": previous, "artifact_sha256": actual}
