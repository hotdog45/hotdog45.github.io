import os
from pathlib import Path
import tempfile
import unittest
from release import release, activate


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        release(self.root, "v1", "healthy v1")
        activate(self.root, "v1", None, lambda p: True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_success_switches_to_exact_artifact(self):
        release(self.root, "v2", "healthy v2")
        result = activate(self.root, "v2", "releases/v1", lambda p: (p / "index.txt").read_text() == "healthy v2")
        self.assertEqual(result["active"], "v2")
        self.assertEqual(os.readlink(str(self.root / "current")), "releases/v2")

    def test_failed_smoke_rolls_back(self):
        release(self.root, "v2", "broken")
        with self.assertRaisesRegex(RuntimeError, "smoke"):
            activate(self.root, "v2", "releases/v1", lambda p: False)
        self.assertEqual(os.readlink(str(self.root / "current")), "releases/v1")
        self.assertEqual((self.root / "current/index.txt").read_text(), "healthy v1")

    def test_tampered_artifact_never_activated(self):
        release(self.root, "v2", "healthy v2")
        (self.root / "releases/v2/index.txt").write_text("changed")
        with self.assertRaisesRegex(ValueError, "hash"):
            activate(self.root, "v2", "releases/v1", lambda p: True)
        self.assertEqual(os.readlink(str(self.root / "current")), "releases/v1")

    def test_stale_intent_does_not_overwrite(self):
        release(self.root, "v2", "healthy v2")
        with self.assertRaisesRegex(RuntimeError, "stale"):
            activate(self.root, "v2", "releases/v0", lambda p: True)

    def test_release_is_not_overwritten(self):
        with self.assertRaises(FileExistsError):
            release(self.root, "v1", "different")


if __name__ == "__main__":
    unittest.main()
