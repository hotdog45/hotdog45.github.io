import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

public final class BoundedFutures {
    static <T> CompletableFuture<T> submit(Executor executor, Supplier<T> work) {
        CompletableFuture<T> output = new CompletableFuture<>();
        try {
            executor.execute(() -> {
                try { output.complete(work.get()); }
                catch (Throwable error) { output.completeExceptionally(error); }
            });
        } catch (RejectedExecutionException rejected) {
            output.completeExceptionally(rejected);
        }
        return output;
    }

    static ThreadPoolExecutor pool() {
        return new ThreadPoolExecutor(1, 1, 0L, TimeUnit.MILLISECONDS,
                new ArrayBlockingQueue<Runnable>(1), new ThreadPoolExecutor.AbortPolicy());
    }

    static void await(CountDownLatch latch) {
        try {
            if (!latch.await(2, TimeUnit.SECONDS)) throw new AssertionError("latch timed out");
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(interrupted);
        }
    }

    static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label);
    }

    public static void main(String[] args) throws Exception {
        ThreadPoolExecutor executor = pool();
        CountDownLatch release = new CountDownLatch(1);
        try {
            CompletableFuture<Integer> chain = submit(executor, () -> 20)
                    .thenCompose(n -> submit(executor, () -> n + 1))
                    .thenApply(n -> n * 2);
            check(chain.get(2, TimeUnit.SECONDS) == 42, "composition");

            CountDownLatch started = new CountDownLatch(1);
            CompletableFuture<Integer> running = submit(executor, () -> {
                started.countDown(); await(release); return 1;
            });
            await(started);
            CompletableFuture<Integer> queued = submit(executor, () -> 2);
            CompletableFuture<Integer> rejected = submit(executor, () -> 3);
            try { rejected.get(1, TimeUnit.SECONDS); throw new AssertionError("rejection missing"); }
            catch (ExecutionException expected) {
                check(expected.getCause() instanceof RejectedExecutionException, "rejection type");
            }
            try { running.get(5, TimeUnit.MILLISECONDS); throw new AssertionError("timeout missing"); }
            catch (TimeoutException expected) { check(!running.isDone(), "timeout canceled task"); }
            release.countDown();
            check(running.get(2, TimeUnit.SECONDS) == 1, "running result");
            check(queued.get(2, TimeUnit.SECONDS) == 2, "queued result");

            CountDownLatch startedAgain = new CountDownLatch(1);
            CountDownLatch releaseAgain = new CountDownLatch(1);
            CountDownLatch finished = new CountDownLatch(1);
            AtomicBoolean interrupted = new AtomicBoolean(false);
            CompletableFuture<Integer> logical = submit(executor, () -> {
                startedAgain.countDown();
                try { releaseAgain.await(); }
                catch (InterruptedException error) { interrupted.set(true); }
                finally { finished.countDown(); }
                return 7;
            });
            await(startedAgain);
            check(logical.cancel(true), "logical cancellation");
            releaseAgain.countDown();
            await(finished);
            check(!interrupted.get(), "CompletableFuture unexpectedly interrupted worker");
            System.out.println("PASS: composition, bounded rejection, wait timeout, cancellation distinction");
        } finally {
            release.countDown();
            executor.shutdownNow();
            check(executor.awaitTermination(2, TimeUnit.SECONDS), "executor cleanup");
        }
    }
}
