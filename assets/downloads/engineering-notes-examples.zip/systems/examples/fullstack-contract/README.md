# Isolated source snapshot and integration proof

Seven unchanged files were copied from the authored portfolio Demo. Their paths
and SHA-256 values are in `source-snapshot.json`. This is a review snapshot, not
a claim that the currently evolving public repository has identical structure.

The only added test files are `scripts/bridge-test.mjs` and
`demos/engagement-service/blog_bridge_test.go`.

With an existing Node>=18.20 and Go1.23 toolchain:

```sh
node scripts/check-demo-job.mjs
node scripts/run-demo-job.mjs
cd demos/engagement-service
BLOG_NODE=/absolute/path/to/node go test -race -v ./...
```

The integration test creates a new Go service on an OS-assigned loopback port.
A test-only fetch adapter routes the original Node client's validated4738 URL
to that isolated port. It executes actual HTTP and handler logic, while leaving
the original client, fixture, Go source and shared4738 service unchanged.
`bridge-evidence.json` records the first batch and second replay.

React source is copied for code review only. No browser, mobile layout, build,
production deployment or persistence guarantee is newly validated here.
All data is synthetic. Events/room state are process memory only. No model,
media provider, wallet, chain transaction or remote account is accessed.
