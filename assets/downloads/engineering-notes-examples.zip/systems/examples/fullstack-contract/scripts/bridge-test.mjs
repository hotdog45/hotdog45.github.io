import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {runBatch} from './run-demo-job.mjs';

// Test-only adapter: original client validation stays at4738, transport goes
// to this test's isolated Go server. No shared demo process is contacted.
const transport = globalThis.fetch;
const isolated = new URL(process.argv[2]);
assert.equal(isolated.hostname, '127.0.0.1');
const fixture = JSON.parse(await fs.readFile(new URL('../demos/engagement-service/fixtures.json', import.meta.url)));
let requests = [];
globalThis.fetch = async (url, options) => {
  const target = new URL(url);
  assert.equal(target.origin, 'http://127.0.0.1:4738');
  const response = await transport(new URL(target.pathname, isolated), options);
  requests.push({id: JSON.parse(options.body).id, status: response.status});
  return response;
};
try {
  const endpoint = 'http://127.0.0.1:4738/demo-api/events';
  const first = await runBatch(endpoint, fixture.events);
  const firstTrace = [...requests];
  assert.deepEqual([first.input, first.unique, first.filtered, first.retries], [5,4,1,1]);
  assert.ok(first.results.every(r => r.duplicate === false));
  assert.deepEqual(first.results.map(r => r.id), ['demo-101','demo-102','demo-103','demo-104']);
  assert.equal(firstTrace.find(r => r.id === 'demo-103').status, 503);
  assert.equal(first.results.find(r => r.id === 'demo-103').attempts, 2);
  requests = [];
  const replay = await runBatch(endpoint, fixture.events);
  const replayTrace = [...requests];
  assert.deepEqual([replay.unique, replay.filtered, replay.retries], [4,1,0]);
  assert.ok(replay.results.every(r => r.duplicate === true));
  assert.deepEqual(replay.results.map(r => r.id), first.results.map(r => r.id));
  assert.ok(replayTrace.every(r => r.status === 200));
  await assert.rejects(() => runBatch(endpoint, [{...fixture.events[0], payload:'changed'}]), /HTTP 409/);
  const before = requests.length;
  await assert.rejects(() => runBatch('https://unrelated.example/events', fixture.events), /local fixture/);
  assert.equal(requests.length, before);
  const evidence = {mode:'isolated-loopback-adapter', node:process.version,
    first:{...first, trace:firstTrace}, replay:{...replay, trace:replayTrace},
    negativeChecks:['same ID changed payload gives409', 'external endpoint rejected before fetch']};
  console.log(JSON.stringify(evidence));
} finally {
  globalThis.fetch = transport;
}
