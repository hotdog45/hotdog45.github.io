package main

import (
	"encoding/json"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

// Executes the original Node runBatch against the original Go handler in a
// fresh service. Only the test adapter changes the destination port.
func TestBlogNodeGoBridge(t *testing.T) {
	node := os.Getenv("BLOG_NODE")
	if node == "" {
		t.Fatal("set BLOG_NODE to an existing Node>=18.20 executable")
	}
	server := httptest.NewServer(NewService().Handler())
	defer server.Close()
	command := exec.Command(node, "../../scripts/bridge-test.mjs", server.URL)
	out, err := command.CombinedOutput()
	if err != nil {
		t.Fatalf("node bridge: %v\n%s", err, out)
	}
	var evidence map[string]any
	if err := json.Unmarshal(out, &evidence); err != nil {
		t.Fatalf("invalid evidence: %v\n%s", err, out)
	}
	pretty, err := json.MarshalIndent(evidence, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join("..", "..", "bridge-evidence.json"), append(pretty, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
	t.Log(string(pretty))
}

func TestBlogNewServiceDoesNotPersistEventReceipts(t *testing.T) {
	body := `{"id":"restart-boundary","kind":"fixture","payload":"x"}`
	before := NewService().Handler()
	if req(before, "POST", "/demo-api/events", body).Code != 201 || req(before, "POST", "/demo-api/events", body).Code != 200 {
		t.Fatal("expected create then replay")
	}
	after := NewService().Handler()
	if req(after, "POST", "/demo-api/events", body).Code != 201 {
		t.Fatal("fresh process model must not claim persisted receipts")
	}
}
