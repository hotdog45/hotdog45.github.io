import unittest
from copy import deepcopy
from gate import fixtures, grade, evaluate


class ContractGraderTests(unittest.TestCase):
    def setUp(self):
        self.cases, self.outputs = fixtures()

    def test_good_fixtures_pass(self):
        for case in self.cases:
            with self.subTest(case=case["id"]):
                self.assertEqual(grade(case, *self.outputs[case["id"]]), [])

    def test_wrong_routing_fails(self):
        case = self.cases[1]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        candidate["action"] = "answer"
        self.assertIn("routing", grade(case, candidate, observed))

    def test_unsupported_fact_fails(self):
        case = self.cases[0]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        candidate["facts"].append("refund_guaranteed")
        self.assertIn("unsupported_fact", grade(case, candidate, observed))

    def test_missing_source_fails(self):
        case = self.cases[0]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        candidate["citations"] = []
        self.assertIn("missing_source", grade(case, candidate, observed))

    def test_unauthorized_tool_and_effect_fail(self):
        case = self.cases[2]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        observed.update(tool_calls=["read_other_tenant"], effects=["private-data-read"])
        failed = grade(case, candidate, observed)
        self.assertIn("tool_boundary", failed)
        self.assertIn("outcome", failed)

    def test_claimed_handoff_without_ticket_fails(self):
        case = self.cases[1]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        observed["effects"] = []
        observed.pop("handoff")
        self.assertIn("outcome", grade(case, candidate, observed))
        self.assertIn("handoff_receipt", grade(case, candidate, observed))

    def test_candidate_cannot_reference_a_different_ticket(self):
        case = self.cases[1]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        candidate["handoff"]["id"] = "ticket-invented-by-model"
        self.assertEqual(observed["effects"], case["expected_effects"])
        self.assertIn("handoff_receipt_mismatch", grade(case, candidate, observed))

    def test_candidate_status_must_match_observed_receipt(self):
        case = self.cases[1]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        candidate["handoff"]["status"] = "resolved"
        self.assertIn("handoff_receipt_mismatch", grade(case, candidate, observed))

    def test_observed_receipt_must_match_actual_effect(self):
        case = self.cases[1]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        observed["handoff"]["id"] = "ticket-disconnected-from-state"
        candidate["handoff"]["id"] = observed["handoff"]["id"]
        self.assertEqual(observed["effects"], case["expected_effects"])
        self.assertIn("handoff_outcome_mismatch", grade(case, candidate, observed))

    def test_replay_has_same_report(self):
        self.assertEqual(evaluate(self.cases, self.outputs), evaluate(self.cases, self.outputs))

    def test_malformed_output_fails_closed(self):
        case = self.cases[0]
        candidate, observed = deepcopy(self.outputs[case["id"]])
        candidate["facts"] = "not-a-list"
        self.assertEqual(grade(case, candidate, observed), ["schema"])
        self.assertEqual(grade(case, None, observed), ["schema"])


if __name__ == "__main__":
    unittest.main()
