package cancellation

import (
	"context"
	"errors"
	"sync"
)

type job struct{ index, value int }
type result struct {
	index, value int
	err          error
}

// Map owns and joins every goroutine it starts. work must honor ctx.
// On failure, partial output is discarded rather than presented as complete.
func Map(parent context.Context, values []int, workers int,
	work func(context.Context, int) (int, error)) ([]int, error) {
	if workers < 1 {
		return nil, errors.New("workers must be positive")
	}
	ctx, cancel := context.WithCancel(parent)
	defer cancel()
	jobs := make(chan job)
	results := make(chan result)
	var group sync.WaitGroup
	group.Add(1 + workers)
	go func() {
		defer group.Done()
		defer close(jobs) // The only producer owns this close.
		for i, n := range values {
			select {
			case jobs <- job{i, n}:
			case <-ctx.Done():
				return
			}
		}
	}()
	for i := 0; i < workers; i++ {
		go func() {
			defer group.Done()
			for j := range jobs {
				if ctx.Err() != nil {
					return
				}
				value, err := work(ctx, j.value)
				select {
				case results <- result{j.index, value, err}:
				case <-ctx.Done():
					return
				}
				if err != nil {
					return
				}
			}
		}()
	}
	go func() {
		group.Wait()
		close(results) // No sender can still be running.
	}()
	output := make([]int, len(values))
	var firstErr error
	for r := range results {
		if r.err != nil && firstErr == nil {
			firstErr = r.err
			cancel()
		}
		output[r.index] = r.value
	}
	if firstErr != nil {
		return nil, firstErr
	}
	if err := parent.Err(); err != nil {
		return nil, err
	}
	return output, nil
}
