module example.com/blog/cancellation

go 1.15
