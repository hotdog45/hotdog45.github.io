package cancellation

import (
	"context"
	"errors"
	"reflect"
	"sync/atomic"
	"testing"
	"time"
)

func TestMapSuccessPreservesInputOrder(t *testing.T) {
	got, err := Map(context.Background(), []int{3, 1, 2}, 2,
		func(_ context.Context, n int) (int, error) { return n * n, nil })
	if err != nil || !reflect.DeepEqual(got, []int{9, 1, 4}) {
		t.Fatalf("output=%v error=%v", got, err)
	}
}

func TestMapFailureDiscardsPartialOutput(t *testing.T) {
	expected := errors.New("dependency failed")
	got, err := Map(context.Background(), []int{1, 2, 3, 4}, 2,
		func(_ context.Context, n int) (int, error) {
			if n == 3 {
				return 0, expected
			}
			return n * n, nil
		})
	if got != nil || !errors.Is(err, expected) {
		t.Fatalf("partial output=%v error=%v", got, err)
	}
}

func TestCancelWaitsForWorkCleanup(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	started := make(chan struct{}, 2)
	finished := make(chan error, 1)
	var active int32
	go func() {
		_, err := Map(ctx, []int{1, 2, 3, 4}, 2,
			func(ctx context.Context, _ int) (int, error) {
				atomic.AddInt32(&active, 1)
				defer atomic.AddInt32(&active, -1)
				started <- struct{}{}
				<-ctx.Done()
				return 0, ctx.Err()
			})
		finished <- err
	}()
	for i := 0; i < 2; i++ {
		select {
		case <-started:
		case <-time.After(time.Second):
			t.Fatal("worker did not start")
		}
	}
	cancel()
	select {
	case err := <-finished:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("error=%v", err)
		}
		if got := atomic.LoadInt32(&active); got != 0 {
			t.Fatalf("active=%d", got)
		}
	case <-time.After(time.Second):
		t.Fatal("cancel did not stop owned workers")
	}
}

func TestAlreadyCanceledDoesNotCallWork(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := Map(ctx, []int{1}, 1, func(context.Context, int) (int, error) {
		t.Fatal("work called after cancellation")
		return 0, nil
	})
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("error=%v", err)
	}
}

func TestInvalidWorkerLimit(t *testing.T) {
	_, err := Map(context.Background(), nil, 0, nil)
	if err == nil {
		t.Fatal("missing validation error")
	}
}
