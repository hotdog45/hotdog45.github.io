import assert from 'node:assert/strict';
import {formatUnits} from './units.mjs';
assert.equal(formatUnits('9007199254740993123456789',18),'9007199.254740993123456789');
assert.equal(formatUnits('1',6),'0.000001');
assert.equal(formatUnits('0',18),'0.000000000000000000');
assert.equal(formatUnits('7',0),'7');
for(const raw of ['-1','1.0','1e18',''])assert.throws(()=>formatUnits(raw,18));
for(const decimals of [-1,37,1.5])assert.throws(()=>formatUnits('1',decimals));
console.log('PASS: 11 exact integer / precision / invalid-input assertions');
