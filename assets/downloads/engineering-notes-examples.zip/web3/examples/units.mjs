function formatUnits(raw, decimals) {
  if (!/^\d+$/.test(raw)) throw new Error('invalid integer')
  if (!Number.isInteger(decimals) || decimals < 0 || decimals > 36)
    throw new Error('unsupported decimals')
  const value = BigInt(raw)
  const scale = 10n ** BigInt(decimals)
  if (decimals === 0) return value.toString()
  const fraction = (value % scale).toString().padStart(decimals, '0')
  return `${value / scale}.${fraction}`
}
export { formatUnits };
